import conn from "../db.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import {check, validationResult} from "express-validator";
import config from 'config';

const generateAccesToken = (id, role) => {
    const payload = {
        id,
        role
    }
    return jwt.sign(payload, config.get('secretKey'), {expiresIn: '24h'})
}

export default class AuthController{
        static async registration(req, res) {
            console.log('Request called')
            try{
            const errors = validationResult(req)
            const {email, name, role, password} = req.body
            const sql = `SELECT * FROM userList WHERE email = '${email}'`
            const sql2 = `INSERT INTO userList SET ?`
            const candidate = (await conn.query(sql))[0][0]

            if(!errors.isEmpty){
                return res.status(400).json({message: 'Uncorrect request.' , errors})
            }
            else if(candidate){
                return res.status(400).json({message: 'User with such Email already exists.'})
            } else {
                const hashPassword = await bcrypt.hash(password, 5)
                await conn.query(sql2, {email, name, role : 0, password: hashPassword})
                return res.json({message: 'User created succesfully.'}).status(200)
            }
        } catch(e) {
            console.log(e)
            res.send({message: "Server error: " + e})
        }
    }

    static async login(req, res){
        console.log('Request called')
        try{
            const {email, password} = req.body
            const sql = `SELECT * FROM userList WHERE email = '${email}'`
            const user = (await conn.query(sql))[0][0]
            if (!user) {
                return res.status(400).json({message: "User not found."})
            }
            const isPassValid = bcrypt.compareSync(password, user.password)
            if (!isPassValid){
                return res.status(400).json({message: "Invalid password."})
            }
            const token = generateAccesToken(user.id, user.role)
            return res.json({
                token,
                user: {
                    id: user.id,
                    email: user.email,
                    name: user.name,
                    role: user.role,
                    balance: user.balance
                }
            })

        } catch(e) {
            console.log(e)
            res.send({message: "Server error: " + e})
        }
    }
}