import conn from "../db.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import {check, validationResult} from "express-validator";
import config from 'config';
import OrderService from "../service/OrderService.js";
import {auth} from '../middleware/routerSecurity.js';



export default class OrderController {
    static async createOrder(req, res){
        const status = parseInt(req.headers.orderstatus, 10)
        const body = req.body
        const goods = (req.body.goods ? req.body.goods : undefined)
        const jsonGoods = req.body.goods ? JSON.stringify(req.body.goods) : undefined
        const address = (req.body.address)
        const jsonAddress = JSON.stringify(req.body.address)
        const goodsCount = req.body.goodsCount
        const jsonGoodsCount = JSON.stringify(req.body.goodsCount)
        const deliveryPriceForCustomer = req.body.deliveryPriceForCustomer
        const telephoneNumber = req.body.telephoneNumber
        const discount = req.body.discount ? req.body.discount : 0
        const user = req.body.user
        const comment = req.body.comment
        const payment = req.body.payment ? req.body.payment : undefined
        const jsonPayment = req.body.payment ? JSON.stringify(req.body.payment) : undefined
        const prices = await OrderService.getPricesOF(goods)
        const sum = OrderService.getSum(prices, goodsCount, deliveryPriceForCustomer, discount)
        const jsonPrices = goods ? JSON.stringify(await OrderService.getPricesOF(goods)) : undefined
        const sumOfPayment = OrderService.getSumOfPayment(payment)
        const paymentSum = OrderService.getPaymentSum(payment)
        const wholeSaleSum = OrderService.getWholesaleSum(prices, goodsCount)
    
        if (status === 0 && sumOfPayment === sum) {
            body.status = 0
            body.goods = jsonGoods
            body.sum = sum
            body.address = jsonAddress
            body.goodsCount = jsonGoodsCount
            body.prices = jsonPrices
            body.payment = jsonPayment
            body.paymentSum = paymentSum
            body.wholesaleSum = wholeSaleSum
            delete body.id
            const sql = `INSERT INTO orders SET ?`
            try {
                await conn.query(sql, body)
                res.sendStatus(200)
            } catch (e) {
                res.send({message: 'server error: ' + e})
            }
        } else if (status === 5) {
            const sql = `SELECT * FROM finished_orders WHERE id = ${body.id}`
            const sql2 = `INSERT INTO orders SET ?`
            const sql3 = `UPDATE finished_orders SET children = 1 WHERE id = ${body.id}`
            try {
                const result = (await conn.query(sql))[0][0]
                if(!result || result.children === 1){
                    res.send({message: 'ERROR 407'})
                } else if (result != undefined) {
                    result.goods = (JSON.stringify(result.goods))
                    result.goodsCount = jsonGoodsCount
                    result.address = jsonAddress
                    result.telephoneNumber = telephoneNumber
                    result.pickup = req.body.pickup
                    result.deliveryPriceForCustomer = deliveryPriceForCustomer
                    result.status = 0
                    result.deliveryPriceForStore = 0
                    const pricesTemp = result.prices
                    result.prices = JSON.stringify(pricesTemp)
                    result.discount = discount
                    delete result.payment
                    delete result.income
                    delete result.creationDate
                    delete result.finishedDate
                    delete result.paymentSum
                    delete result.deliver
                    result.comment = comment
                    result.prototype = result.id
                    delete result.id
                    result.retOrEx = 1
                    result.sum = OrderService.getSum(pricesTemp, goodsCount, deliveryPriceForCustomer, discount)
                    result.wholesaleSum = -(OrderService.getWholesaleSum(pricesTemp, goodsCount))
                    delete result.children
                    delete result.incomeForUser
    
                    await conn.query(sql2, result)
                    await conn.query(sql3)
                    res.sendStatus(200)
                }
            } catch (e) {
                res.send(e)
            }
        } else {
            res.send({message: 'server error'})
        }
    }
    static async getAllOrders(req, res){
        console.log(req.query)
        const status = parseInt(req.query.status)
        const pickup = parseInt(req.query.pickup)
        const sql = `SELECT * FROM orders WHERE status IN (${status})`
        let sql2 = ''
        if (status === 1) {
            sql2 = ' AND pickup = ' + pickup
        }
        const sql3 = sql + sql2
        try {
            const result = await conn.query(sql3)
            res.send(result[0])
        } catch (e) {
            res.send({message: 'server error: ' + e})
        }
    }
    static async getOneOrder(req, res){
        const id = req.params.id
        const sql = `SELECT * FROM orders WHERE id = ${parseInt(id)}`
        const sql2 = `SELECT * FROM finished_orders WHERE id = ${parseInt(id)}`
    
        try {
            const result = await conn.query(sql)
            if (!result[0][0]) {
                const result2 = await conn.query(sql2)
                if (!result2[0][0]) {
                    res.send({message: 'Заказ не найден'})
                } else {
                    res.send(result2[0][0])
                }
            } else {
                res.send(result[0][0])
            }
        } catch (e) {
            res.send(e)
        }
    }
    static async getAllFinishedOrders(req, res){
        const sql = `SELECT * FROM finished_orders WHERE finishedDate BETWEEN '${req.body.firstDate}' AND '${req.body.secondDate}'`
        try {
            const result = await conn.query(sql)
            res.send(result[0][0])
        } catch (e) {
            res.send(e)
        }
    }
    static async editOrder(req, res){
        const body = req.body
        const sql = `SELECT * FROM orders WHERE id = ${parseInt(req.params.id)}`
        const sql3 = `UPDATE orders SET ? WHERE id = ${parseInt(req.params.id)}`
        try {
            const result = (await conn.query(sql))[0][0]
            if((result.retOrEx === 0 && OrderService.getSum(await OrderService.getPricesOF(body.goods? body.goods : result.goods), body.goodsCount , body.deliveryPriceForCustomer? body.deliveryPriceForCustomer : result.deliveryPriceForCustomer, body.discount ? body.discount : result.discount) != OrderService.getSumOfPayment(body.payment? body.payment : result.payment))){
                res.send('fuck you')
            } else if ((result.status === 0 && (body.deliver || body.deliveryPriceForStore) ) || (body.goods && body.goodsCount === undefined) || body.id != undefined || body.pickup != undefined || !result || ( ((result.retOrEx === 1) && (body.goods || body.prices || body.payment)))) {
                res.send({message : 'Ошибка: Order not found or Incorrect JSON body of query.'})
            } else {
                const goods = body.goods? body.goods : undefined
                const goodsCount = body.goodsCount ? body.goodsCount : undefined
                const address = body.address ? body.address : undefined
                const telephoneNumber = body.telephoneNumber ? body.telephoneNumber : undefined
                const deliveryPriceForCustomer = body.deliveryPriceForCustomer ? body.deliveryPriceForCustomer : undefined
                const deliveryPriceForStore = body.deliveryPriceForStore ? body.deliveryPriceForStore : undefined
                const discount = body.discount ? body.discount : undefined
                const deliver = body.deliver ? body.deliver : undefined
                const payment = body.payment ? body.payment : undefined
                const comment = body.comment ? body.comment : undefined
    
                result.goodsCount = goodsCount? goodsCount : result.goodsCount
                result.deliveryPriceForCustomer = deliveryPriceForCustomer ? deliveryPriceForCustomer : (result.deliveryPriceForCustomer? result.deliveryPriceForCustomer : 0)
                result.discount = discount ? discount : (result.discount ? result.discount : 0)
                   
                if((goods || goodsCount || deliveryPriceForCustomer || discount) && result.retOrEx === 0){
                    console.log(1)
                    
                    result.goods = goods? goods : result.goods
                    result.prices = await OrderService.getPricesOF(result.goods)
                    result.sum = OrderService.getSum(result.prices, result.goodsCount, result.deliveryPriceForCustomer, result.discount)
                    result.wholesaleSum = OrderService.getWholesaleSum(result.prices, result.goodsCount )
                
                } else if ((goodsCount || deliveryPriceForCustomer || discount) && result.retOrEx === 1 && !goods){
                    console.log(2)
    
                    result.sum = OrderService.getSum(result.prices, result.goodsCount, result.deliveryPriceForCustomer, result.discount)
                    result.wholesaleSum = -(OrderService.getWholesaleSum(result.prices, result.goodsCount))
                }
    
                result.goods = JSON.stringify(result.goods)
                result.prices = JSON.stringify(result.prices)
                result.goodsCount = JSON.stringify(result.goodsCount)
    
                result.address = address ? JSON.stringify(address) : JSON.stringify(result.address)
                result.telephoneNumber = telephoneNumber ? telephoneNumber : result.telephoneNumber
                result.deliveryPriceForStore = deliveryPriceForStore ? deliveryPriceForStore : result.deliveryPriceForStore
                result.paymentSum = OrderService.getPaymentSum(result.payment)
                if(!(result.status === 0)) result.deliver = deliver ? deliver : result.deliver
                result.payment = payment ? JSON.stringify(payment) : JSON.stringify(result.payment)
                result.comment = comment ? comment : result.comment
    
                delete result.id
                delete result.status
                delete result.income
                delete result.creationDate
                delete result.prototype
                delete result.cancelOrWhileDel
                delete result.pickup
                delete result.user
    
                await conn.query(sql3, result)
                res.sendStatus(200)
            }
        } catch (e) {
            res.send(e)
        }
    }
    static async acceptOrder (req, res) {
        const sql = `SELECT * FROM orders where id = ${parseInt(req.params.id)} AND status = 0`
        const sql2 = `UPDATE orders SET status = 1, ? where id = ${req.params.id}`
        const sql4 = `UPDATE orders SET status = 1 where id = ${req.params.id}`
    
        try {
            const result = (await conn.query(sql))[0][0]
            if (result) {
                if (result.pickup === 0) {
                    if(req.body.deliver != undefined && req.body.deliveryPriceForStore != undefined){
                        await conn.query(sql2, req.body)
                        res.sendStatus(200)
                    } else {
                        res.send({message: "server error 2"})
                    }
                } else if (result.pickup === 1) {
                    await conn.query(sql4)
                    res.sendStatus(200)
                }
            } else {
                res.send({message: 'Заказ не найден'})
            }
        } catch (e) {
            res.send(e)
        }
    }
    static async finishOrder (req, res){
        const sql = `SELECT * FROM orders WHERE id = ${req.params.id}`
        const sql2 = `DELETE FROM orders WHERE id = ${req.params.id}`
        const sql3 = `INSERT INTO finished_orders SET ?`
        const cancelOrder = parseInt(req.query.cancel ? req.query.cancel : 0)
        const whileDelivering = parseInt(req.query.whileDelivering ? req.query.whileDelivering : 0)
        const didPay = parseInt(req.query.didPay ? req.query.didPay : 0)
    
        try {
            const body = (await conn.query(sql))[0][0]
            const prices = body.prices
            const goodsCount = body.goodsCount
            body.goods = JSON.stringify(body.goods)
            body.goodsCount = JSON.stringify(body.goodsCount)
            body.address = JSON.stringify(body.address)
            body.payment = JSON.stringify(body.payment)
            body.prices = JSON.stringify(body.prices)
            body.status = 2
            if (body.retOrEx === 1) {
                body.income = -(-(OrderService.getSum(prices, goodsCount, -body.deliveryPriceForCustomer, -body.discount)) - body.deliveryPriceForStore - body.wholesaleSum)
                body.incomeForUser = Math.floor(body.income / 2)
            } else if (cancelOrder === 1) {
                body.income = 0
                body.incomeForUser = (whileDelivering === 1) ? -body.deliveryPriceForStore + (didPay ? body.deliveryPriceForCustomer : 0) : 0
                body.cancelOrWhileDel = 1
            } else {
                body.income = body.sum - body.wholesaleSum - body.deliveryPriceForStore - body.paymentSum
                body.incomeForUser = Math.floor(body.income / 2)
            }
            await conn.query(sql3, body)
            await conn.query(sql2)
            res.sendStatus(200)
        } catch (e) {
            res.send(e)
        }
    }
}