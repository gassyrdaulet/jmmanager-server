import conn from '../db.js';

export default class OrderService {

    static getSum(prices, goodsCount, deliveryPriceForCustomer, discount) {
        let sum = 0
        const discountTemp = discount ? discount : 0
        const deliveryPriceForCustomerTemp = deliveryPriceForCustomer ? deliveryPriceForCustomer : 0
        for (let i in prices) {
            sum += (prices[i].SECOND_PRICE * goodsCount[i])
        }
        const result = sum + deliveryPriceForCustomerTemp - discountTemp
        return result
    }

    static getWholesaleSum(prices, goodsCount) {
        let sum = 0
        for (let i in prices) {
            sum += (prices[i].FIRST_PRICE * goodsCount[i])
        }
        return sum
    }

    static getPaymentSum(payment) {
        let sum = 0
        for (let i in payment) {
            const part = payment[i].sum
            const percent = payment[i].percent
            sum += ((part * percent) / 100)
        }
        return sum
    }

    static async getPricesOF(goods) {
        let prices = {}
        for (let i in goods) {
            const sql = `SELECT FIRST_PRICE, SECOND_PRICE FROM goods WHERE id = ${goods[i]}`
            const valuesFromDB = await conn.query(sql)
            prices[i] = valuesFromDB[0][0]
        }
        return prices
    }

    static getIncome(sum, payment, wholesaleSum, deliveryPriceForStore) {
        const result = sum - payment - deliveryPriceForStore - wholesaleSum
        return result
    }

    static getSumOfPayment(payment) {
        let sum = 0
        for (let i in payment) {
            sum += (payment[i].sum)
        }
        const result = sum
        return result
    }

}