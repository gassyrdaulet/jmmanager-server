import { Router } from "express";
import conn from "../db.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import {check, validationResult} from "express-validator";
import config from 'config';
import OrderService from "../service/OrderService.js";
import {auth} from '../middleware/routerSecurity.js';
import OrderController from "../controllers/OrderController.js";

const router = new Router()

router.post('/create', OrderController.createOrder)
router.get('/', OrderController.getAllOrders)
router.get('/details/:id', OrderController.getOneOrder)
router.get('/finished/', OrderController.getAllFinishedOrders)
router.patch('/edit/:id', OrderController.editOrder)
router.patch('/accept/:id', OrderController.acceptOrder)
router.patch('/finish/:id', OrderController.finishOrder)
router.get('/testing', (req, res) => {
    res.send('bomba')
})

export default router